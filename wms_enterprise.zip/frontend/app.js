let products = [];

function add(){
  const name = document.getElementById('name').value;
  products.push(name);
  render();
}

function render(){
  document.getElementById('list').innerHTML =
    products.map(p=>`<li>${p}</li>`).join('');
}
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req,res)=>res.send('WMS API OK'));

app.listen(3001, ()=>console.log('Backend rodando na porta 3001'));